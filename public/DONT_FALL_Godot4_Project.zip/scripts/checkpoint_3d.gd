extends Area3D
class_name MythoriaCheckpoint3D

## MYTHORIA games — By ahmed
## Reusable 3D Sanctuary Checkpoint with independent per-player ownership,
## ordered progression validation, ancient stone pillars, golden runes,
## glowing sapphire crystal core, and magical particle burst.

signal checkpoint_activated(player_id: String, checkpoint_index: int, safe_position: Vector3, safe_yaw_deg: float)

@export var checkpoint_index: int = 1
@export var safe_yaw_deg: float = 180.0

var activated_by_players: Dictionary = {} # player_id -> bool
var pulse_timer: float = 0.0
var local_time: float = 0.0

var ring_mesh: MeshInstance3D
var left_crystal: MeshInstance3D
var right_crystal: MeshInstance3D
var center_crown_gem: MeshInstance3D
var arch_beam: MeshInstance3D
var particles_gold: CPUParticles3D
var particles_blue: CPUParticles3D

func _ready() -> void:
	collision_layer = 1
	collision_mask = 1
	monitoring = true
	monitorable = true
	_build_mythoria_visuals()
	body_entered.connect(_on_body_entered)

func _build_mythoria_visuals() -> void:
	# Collision trigger box
	var col_shape := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(5.6, 4.2, 3.2)
	col_shape.shape = box
	col_shape.position = Vector3(0.0, 2.1, 0.0)
	add_child(col_shape)

	var mat_marble := StandardMaterial3D.new()
	mat_marble.albedo_color = Color(0.89, 0.91, 0.95)
	mat_marble.roughness = 0.35

	var mat_gold := StandardMaterial3D.new()
	mat_gold.albedo_color = Color(1.0, 0.82, 0.17)
	mat_gold.metallic = 0.85
	mat_gold.roughness = 0.22
	mat_gold.emission_enabled = true
	mat_gold.emission = Color(0.45, 0.32, 0.04)

	var mat_sapphire := StandardMaterial3D.new()
	mat_sapphire.albedo_color = Color(0.0, 0.90, 1.0)
	mat_sapphire.emission_enabled = true
	mat_sapphire.emission = Color(0.0, 0.78, 1.0)
	mat_sapphire.emission_energy_multiplier = 1.8

	# Glowing Platform Activation Ring
	ring_mesh = MeshInstance3D.new()
	var r_cyl := CylinderMesh.new()
	r_cyl.top_radius = 2.4
	r_cyl.bottom_radius = 2.4
	r_cyl.height = 0.08
	r_cyl.material = mat_gold.duplicate()
	ring_mesh.mesh = r_cyl
	ring_mesh.position = Vector3(0.0, 0.05, 0.0)
	add_child(ring_mesh)

	# Twin Ancient Stone Pillars with Golden Runes & Floating Sapphire Crystals
	for side in [-2.25, 2.25]:
		var pillar := MeshInstance3D.new()
		var p_cyl := CylinderMesh.new()
		p_cyl.top_radius = 0.34
		p_cyl.bottom_radius = 0.38
		p_cyl.height = 2.8
		p_cyl.material = mat_marble
		pillar.mesh = p_cyl
		pillar.position = Vector3(side, 1.45, 0.0)
		add_child(pillar)

		for rune_y in [1.0, 2.0]:
			var rune_band := MeshInstance3D.new()
			var rb_cyl := CylinderMesh.new()
			rb_cyl.top_radius = 0.42
			rb_cyl.bottom_radius = 0.42
			rb_cyl.height = 0.20
			rb_cyl.material = mat_gold
			rune_band.mesh = rb_cyl
			rune_band.position = Vector3(side, rune_y, 0.0)
			add_child(rune_band)

		var crystal := MeshInstance3D.new()
		var c_sphere := SphereMesh.new()
		c_sphere.radius = 0.36
		c_sphere.height = 0.72
		c_sphere.material = mat_sapphire.duplicate()
		crystal.mesh = c_sphere
		crystal.position = Vector3(side, 3.35, 0.0)
		add_child(crystal)
		if side < 0.0:
			left_crystal = crystal
		else:
			right_crystal = crystal

	# Overhead Mythoria Golden Arch & Central Crown Sapphire Emblem
	arch_beam = MeshInstance3D.new()
	var a_box := BoxMesh.new()
	a_box.size = Vector3(5.2, 0.46, 0.46)
	a_box.material = mat_gold.duplicate()
	arch_beam.mesh = a_box
	arch_beam.position = Vector3(0.0, 3.05, 0.0)
	add_child(arch_beam)

	center_crown_gem = MeshInstance3D.new()
	var g_sphere := SphereMesh.new()
	g_sphere.radius = 0.44
	g_sphere.height = 0.88
	g_sphere.material = mat_sapphire.duplicate()
	center_crown_gem.mesh = g_sphere
	center_crown_gem.position = Vector3(0.0, 3.72, 0.0)
	add_child(center_crown_gem)

	# Golden & Blue Magical Particle Emitters
	particles_gold = CPUParticles3D.new()
	particles_gold.emitting = false
	particles_gold.one_shot = true
	particles_gold.amount = 18
	particles_gold.lifetime = 0.75
	particles_gold.explosiveness = 0.92
	particles_gold.direction = Vector3.UP
	particles_gold.spread = 65.0
	particles_gold.initial_velocity_min = 3.0
	particles_gold.initial_velocity_max = 5.5
	particles_gold.position = Vector3(0.0, 1.5, 0.0)
	add_child(particles_gold)

	particles_blue = CPUParticles3D.new()
	particles_blue.emitting = false
	particles_blue.one_shot = true
	particles_blue.amount = 16
	particles_blue.lifetime = 0.75
	particles_blue.explosiveness = 0.92
	particles_blue.direction = Vector3.UP
	particles_blue.spread = 65.0
	particles_blue.initial_velocity_min = 2.8
	particles_blue.initial_velocity_max = 5.0
	particles_blue.position = Vector3(0.0, 1.8, 0.0)
	add_child(particles_blue)

func _process(delta: float) -> void:
	local_time += delta
	var boost: float = 0.0
	if pulse_timer > 0.0:
		pulse_timer = maxf(0.0, pulse_timer - delta)
		boost = sin(pulse_timer * 9.0) * 0.25 + 0.35

	if is_instance_valid(left_crystal):
		left_crystal.position.y = 3.35 + sin(local_time * 3.2 - 1.0) * 0.14 + boost * 0.3
		left_crystal.rotation.y += delta * 2.4
	if is_instance_valid(right_crystal):
		right_crystal.position.y = 3.35 + sin(local_time * 3.2 + 1.0) * 0.14 + boost * 0.3
		right_crystal.rotation.y -= delta * 2.4
	if is_instance_valid(center_crown_gem):
		center_crown_gem.position.y = 3.72 + sin(local_time * 3.6) * 0.12 + boost * 0.32
		center_crown_gem.rotation.y += delta * 3.0

func get_safe_respawn_position(lane_offset_x: float = 0.0) -> Vector3:
	return global_position + Vector3(clampf(lane_offset_x, -1.8, 1.8), 0.75, 0.0)

func _on_body_entered(body: Node3D) -> void:
	if body == null or not body.has_method("try_activate_checkpoint"):
		return
	var safe_pos: Vector3 = get_safe_respawn_position(0.0)
	var did_activate: bool = bool(body.call("try_activate_checkpoint", checkpoint_index, safe_pos, safe_yaw_deg))
	if did_activate:
		var pid: String = str(body.get("player_id")) if "player_id" in body else body.name
		activated_by_players[pid] = true
		pulse_timer = 1.25
		if is_instance_valid(particles_gold):
			particles_gold.restart()
		if is_instance_valid(particles_blue):
			particles_blue.restart()
		if pid == "player_0" and is_instance_valid(ring_mesh):
			var mat := ring_mesh.mesh.surface_get_material(0) as StandardMaterial3D
			if mat != null:
				mat.albedo_color = Color(0.0, 0.90, 1.0)
				mat.emission = Color(0.0, 0.78, 1.0)
		checkpoint_activated.emit(pid, checkpoint_index, safe_pos, safe_yaw_deg)
